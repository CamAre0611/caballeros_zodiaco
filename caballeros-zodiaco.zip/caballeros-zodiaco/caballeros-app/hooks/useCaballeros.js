import { useEffect, useState } from 'react';
import axios from 'axios';

const API = 'http://localhost:5164/api/caballeros';

export const useCaballeros = () => {
  const [caballeros, setCaballeros] = useState([]);

  const fetchCaballeros = async () => {
    const res = await axios.get(`${API}/resiliente`);
    setCaballeros(res.data.Datos || res.data);
  };

  const createCaballero = async (data) => {
    await axios.post(API, data);
    fetchCaballeros();
  };

  const updateCaballero = async (id, data) => {
    await axios.put(`${API}/${id}`, data);
    fetchCaballeros();
  };

  const deleteCaballero = async (id) => {
    await axios.delete(`${API}/${id}`);
    fetchCaballeros();
  };

  useEffect(() => {
    fetchCaballeros();
  }, []);

  return {
    caballeros,
    createCaballero,
    updateCaballero,
    deleteCaballero
  };
};
