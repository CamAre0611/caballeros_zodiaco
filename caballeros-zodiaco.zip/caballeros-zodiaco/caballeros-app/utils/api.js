// services/api.js
import axios from 'axios';

// Cambia esta URL con la URL de tu backend
const backendUrl = 'http://localhost:5164/api/caballeros';

export const fetchCaballeros = async () => {
  try {
    const response = await axios.get(backendUrl);
    return response.data; // Retorna la lista de caballeros que viene de la API
  } catch (error) {
    console.error('Error al obtener los caballeros:', error);
    return [];
  }
};
