import { PanResponder } from 'react-native';

export const createGestureHandler = (onMove) =>
  PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderMove: (_, gestureState) => {
      onMove(gestureState.dx, gestureState.dy);
    },
    onPanResponderRelease: () => {},
  });
