import React from 'react';
import { Modal, View, Text, Button, StyleSheet } from 'react-native';

const ModalHabilidad = ({ visible, habilidad, onClose }) => (
  <Modal visible={visible} transparent animationType="slide">
    <View style={styles.container}>
      <View style={styles.modal}>
        <Text style={styles.text}>Habilidad: {habilidad}</Text>
        <Button title="Cerrar" onPress={onClose} />
      </View>
    </View>
  </Modal>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modal: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 16,
    width: '80%',
    alignItems: 'center',
  },
  text: {
    fontSize: 18,
    marginBottom: 10,
  },
});

export default ModalHabilidad;
