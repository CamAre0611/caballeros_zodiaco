import React from 'react';
import { View, Text, Button, StyleSheet, Image } from 'react-native';

const CaballeroCard = ({ caballero, navigation }) => {
  return (
    <View style={styles.card}>
      <Image source={{ uri: caballero.imagen }} style={styles.image} />
      <Text style={styles.title}>{caballero.nombre}</Text>
      <Button
        title="Ver Detalles"
        onPress={() => navigation.navigate('Detail', { caballeroId: caballero.id })}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    marginBottom: 20,
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
});

export default CaballeroCard;
