import React, { createContext, useState, useEffect } from 'react';
import { getCaballeros } from '../services/api';

export const CaballerosContext = createContext();

export const CaballerosProvider = ({ children }) => {
  const [caballeros, setCaballeros] = useState([]);

  const fetchData = async () => {
    const data = await getCaballeros();
    setCaballeros(data);
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <CaballerosContext.Provider value={{ caballeros, fetchData }}>
      {children}
    </CaballerosContext.Provider>
  );
};
