import React, { useState } from 'react';
import { View, Text, TextInput, Button, ScrollView } from 'react-native';
import { useCaballeros } from '../hooks/useCaballeros';

export default function CreateScreen({ navigation }) {
  const { createCaballero } = useCaballeros();
  const [nuevo, setNuevo] = useState({
    nombre: '',
    constelacion: '',
    rango: '',
    pais: '',
    edad: '',
    habilidad_principal: '',
    imagen_url: ''
  });

  const handleChange = (field, value) => {
    setNuevo({ ...nuevo, [field]: value });
  };

  const handleSave = async () => {
    await createCaballero(nuevo);
    navigation.goBack();
  };

  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <Text>Crear Caballero</Text>
      {Object.keys(nuevo).map((key) => (
        <TextInput
          key={key}
          placeholder={key}
          value={nuevo[key]}
          onChangeText={(text) => handleChange(key, text)}
          style={{ borderBottomWidth: 1, marginVertical: 6 }}
        />
      ))}
      <Button title="Guardar" onPress={handleSave} />
    </ScrollView>
  );
}
