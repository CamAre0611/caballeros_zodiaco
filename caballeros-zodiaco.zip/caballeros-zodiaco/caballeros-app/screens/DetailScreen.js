import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { fetchCaballeroById } from '../services/api';

const DetailScreen = ({ route }) => {
  const { caballeroId } = route.params;
  const [caballero, setCaballero] = useState(null);

  useEffect(() => {
    const loadCaballero = async () => {
      const data = await fetchCaballeroById(caballeroId);
      setCaballero(data);
    };
    loadCaballero();
  }, [caballeroId]);

  if (!caballero) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Cargando...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Image source={{ uri: caballero.imagen }} style={styles.image} />
      <Text style={styles.title}>{caballero.nombre}</Text>
      <Text>{caballero.descripcion}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 50,
    paddingHorizontal: 20,
  },
  image: {
    width: 200,
    height: 200,
    borderRadius: 100,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default DetailScreen;
