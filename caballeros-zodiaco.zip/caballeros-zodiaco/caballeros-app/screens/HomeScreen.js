import React, { useState, useEffect } from 'react';
import { View, FlatList, StyleSheet, Text } from 'react-native';
import { fetchCaballeros } from '../services/api';
import CaballeroCard from '../components/CaballeroCard';

const HomeScreen = ({ navigation }) => {
  const [caballeros, setCaballeros] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadCaballeros = async () => {
      const data = await fetchCaballeros();
      setCaballeros(data);
      setLoading(false);
    };
    loadCaballeros();
  }, []);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Cargando...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={caballeros}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <CaballeroCard caballero={item} navigation={navigation} />
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 50,
    paddingHorizontal: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default HomeScreen;
