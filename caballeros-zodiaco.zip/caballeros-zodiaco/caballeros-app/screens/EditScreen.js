import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, ScrollView } from 'react-native';
import { useCaballeros } from '../hooks/useCaballeros';

export default function EditScreen({ route, navigation }) {
  const { caballero } = route.params;
  const { updateCaballero } = useCaballeros();
  const [editado, setEditado] = useState(caballero);

  const handleChange = (field, value) => {
    setEditado({ ...editado, [field]: value });
  };

  const handleUpdate = async () => {
    await updateCaballero(editado._id || editado.id, editado);
    navigation.goBack();
  };

  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <Text>Editar Caballero</Text>
      {Object.keys(editado).map((key) =>
        key !== '_id' && key !== 'id' ? (
          <TextInput
            key={key}
            placeholder={key}
            value={String(editado[key])}
            onChangeText={(text) => handleChange(key, text)}
            style={{ borderBottomWidth: 1, marginVertical: 6 }}
          />
        ) : null
      )}
      <Button title="Actualizar" onPress={handleUpdate} />
    </ScrollView>
  );
}
