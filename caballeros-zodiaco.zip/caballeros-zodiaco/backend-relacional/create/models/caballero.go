package models

type Caballero struct {
    ID                uint   `json:"id" gorm:"primaryKey"`
    Nombre            string `json:"nombre"`
    Constelacion      string `json:"constelacion"`
    Rango            string `json:"rango"`
    Pais              string `json:"pais"`
    Edad              int    `json:"edad"`
    HabilidadPrincipal string `json:"habilidad_principal"`
    ImagenURL         string `json:"imagen_url"`
}
