package main

import (
	"caballeros-zodiaco/create/controllers"
	"caballeros-zodiaco/create/database"

	"github.com/gin-gonic/gin"
)

func main() {
	// Conectar a la base de datos
	if err := database.ConectarBD(); err != nil {
		panic("No se pudo conectar a la base de datos")
	}

	r := gin.Default()

	// Rutas CRUD
	r.POST("/caballeros", controllers.CreateCaballero)
	r.GET("/caballeros", controllers.GetCaballeros)
	r.PUT("/caballeros/:id", controllers.UpdateCaballero)
	r.DELETE("/caballeros/:id", controllers.DeleteCaballero)

	// Iniciar el servidor
	r.Run(":8080")
}
