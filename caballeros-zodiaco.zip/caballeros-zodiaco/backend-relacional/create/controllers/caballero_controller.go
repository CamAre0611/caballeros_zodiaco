package controllers

import (
	"caballeros-zodiaco/create/database"
	"caballeros-zodiaco/create/models"
	"net/http"

	"github.com/gin-gonic/gin"
)

// 🟢 Crear un nuevo caballero
func CreateCaballero(c *gin.Context) {
	var caballero models.Caballero

	// Vincular el JSON al modelo
	if err := c.ShouldBindJSON(&caballero); err != nil {
		if err.Error() == "EOF" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "El cuerpo de la solicitud está vacío. Por favor, envía un JSON válido."})
		} else {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		}
		return
	}

	// Guardar en la base de datos con GORM
	if err := database.DB.Create(&caballero).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Caballero creado exitosamente", "data": caballero})
}

// 🟡 Obtener todos los caballeros
func GetCaballeros(c *gin.Context) {
	var caballeros []models.Caballero

	// Buscar en la base de datos
	if err := database.DB.Find(&caballeros).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": caballeros})
}

// 🔵 Obtener un caballero por ID
func GetCaballeroByID(c *gin.Context) {
	id := c.Param("id")
	var caballero models.Caballero

	// Buscar por ID en la base de datos
	if err := database.DB.First(&caballero, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Caballero no encontrado"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": caballero})
}

// 🟠 Actualizar un caballero
func UpdateCaballero(c *gin.Context) {
	id := c.Param("id")
	var caballero models.Caballero

	// Verificar si el caballero existe
	if err := database.DB.First(&caballero, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Caballero no encontrado"})
		return
	}

	// Vincular el JSON al modelo
	if err := c.ShouldBindJSON(&caballero); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Guardar cambios en la base de datos
	if err := database.DB.Save(&caballero).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Caballero actualizado correctamente", "data": caballero})
}

// 🔴 Eliminar un caballero
func DeleteCaballero(c *gin.Context) {
	id := c.Param("id")
	var caballero models.Caballero

	// Verificar si el caballero existe
	if err := database.DB.First(&caballero, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Caballero no encontrado"})
		return
	}

	// Eliminar de la base de datos
	if err := database.DB.Delete(&caballero).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Caballero eliminado correctamente"})
}
