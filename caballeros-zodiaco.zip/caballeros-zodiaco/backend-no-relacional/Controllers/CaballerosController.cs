using Microsoft.AspNetCore.Mvc;
using backend_no_relacional.Database;
using backend_no_relacional.Models;
using backend_no_relacional.Helpers;

namespace backend_no_relacional.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CaballerosController : ControllerBase
    {
        private readonly MongoDBService _mongoDBService;

        public CaballerosController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var caballeros = await _mongoDBService.GetCaballerosAsync();
            return Ok(caballeros);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(string id)
        {
            var caballero = await _mongoDBService.GetCaballeroAsync(id);
            if (caballero == null) return NotFound();
            return Ok(caballero);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Caballero caballero)
        {
            await _mongoDBService.CreateCaballeroAsync(caballero);
            return CreatedAtAction(nameof(Get), new { id = caballero.Id }, caballero);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(string id, [FromBody] Caballero caballero)
        {
            var existing = await _mongoDBService.GetCaballeroAsync(id);
            if (existing == null) return NotFound();

            await _mongoDBService.UpdateCaballeroAsync(id, caballero);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var existing = await _mongoDBService.GetCaballeroAsync(id);
            if (existing == null) return NotFound();

            await _mongoDBService.DeleteCaballeroAsync(id);
            return NoContent();
        }

        [HttpGet("resiliente")]
        public async Task<IActionResult> GetResiliente()
        {
            try
            {
                var caballeros = await _mongoDBService.GetCaballerosAsync();
                await BackupFileHelper.SaveBackupAsync(caballeros); // actualizar backup
                return Ok(caballeros);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ MongoDB falló: {ex.Message}");
                var backupData = await BackupFileHelper.ReadBackupAsync();

                if (backupData.Count > 0)
                {
                    return Ok(new
                    {
                        Origen = "Archivo de respaldo",
                        Datos = backupData
                    });
                }

                return StatusCode(500, "No se pudo recuperar la información.");
            }
        }

        [HttpGet("backup")]
        public async Task<IActionResult> GetDesdeBackup()
        {
            var backupData = await BackupFileHelper.ReadBackupAsync();

            if (backupData.Count > 0)
            {
                return Ok(new
                {
                    Origen = "Archivo de respaldo",
                    Datos = backupData
                });
            }

            return NotFound("No hay datos disponibles en el respaldo.");
        }
    }
}
