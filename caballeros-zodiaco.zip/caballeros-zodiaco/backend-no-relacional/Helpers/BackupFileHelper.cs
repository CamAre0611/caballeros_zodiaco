using backend_no_relacional.Models;
using System.Text.Json;

namespace backend_no_relacional.Helpers
{
    public static class BackupFileHelper
    {
        private static readonly string BackupFolder = "Respaldo";
        private static readonly string BackupFilePath = Path.Combine(BackupFolder, "CaballerosBackup.json");

        public static async Task SaveBackupAsync(List<Caballero> caballeros)
        {
            try
            {
                Directory.CreateDirectory(BackupFolder); // Crea la carpeta si no existe
                var json = JsonSerializer.Serialize(caballeros, new JsonSerializerOptions { WriteIndented = true });
                await File.WriteAllTextAsync(BackupFilePath, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error al guardar backup: {ex.Message}");
            }
        }

        public static async Task<List<Caballero>> ReadBackupAsync()
        {
            try
            {
                if (!File.Exists(BackupFilePath)) return new List<Caballero>();

                var json = await File.ReadAllTextAsync(BackupFilePath);
                return JsonSerializer.Deserialize<List<Caballero>>(json) ?? new List<Caballero>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error al leer backup: {ex.Message}");
                return new List<Caballero>();
            }
        }
    }
}
