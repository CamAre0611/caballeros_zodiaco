using backend_no_relacional.Models;
using backend_no_relacional.Database;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// Configurar MongoDBSettings desde appsettings.json
builder.Services.Configure<MongoDBSettings>(
    builder.Configuration.GetSection("MongoDBSettings"));

// Registrar MongoDBService como singleton
builder.Services.AddSingleton<MongoDBService>(sp =>
{
    var settings = sp.GetRequiredService<IOptions<MongoDBSettings>>().Value;
    return new MongoDBService(settings);
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Mostrar errores detallados en desarrollo
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseSwagger();
app.UseSwaggerUI();

app.UseAuthorization();

app.MapControllers();

app.Run();
