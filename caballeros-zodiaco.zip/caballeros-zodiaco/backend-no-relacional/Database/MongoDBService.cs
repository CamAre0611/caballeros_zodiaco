using MongoDB.Driver;
using backend_no_relacional.Models;

namespace backend_no_relacional.Database
{
    public class MongoDBService
    {
        private readonly IMongoCollection<Caballero> _caballerosCollection;

        public MongoDBService(MongoDBSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _caballerosCollection = database.GetCollection<Caballero>(settings.CollectionName);
        }

        public async Task<List<Caballero>> GetCaballerosAsync()
        {
            return await _caballerosCollection.Find(_ => true).ToListAsync();
        }

        public async Task<Caballero> GetCaballeroAsync(string id)
        {
            return await _caballerosCollection.Find(c => c.Id == id).FirstOrDefaultAsync();
        }

        public async Task CreateCaballeroAsync(Caballero caballero)
        {
            await _caballerosCollection.InsertOneAsync(caballero);
        }

        public async Task UpdateCaballeroAsync(string id, Caballero caballero)
        {
            await _caballerosCollection.ReplaceOneAsync(c => c.Id == id, caballero);
        }

        public async Task DeleteCaballeroAsync(string id)
        {
            await _caballerosCollection.DeleteOneAsync(c => c.Id == id);
        }
    }
}
