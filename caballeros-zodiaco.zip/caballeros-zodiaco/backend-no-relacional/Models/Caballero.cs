using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace backend_no_relacional.Models
{
    public class Caballero
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }

        [BsonElement("nombre")]
        public string Nombre { get; set; } = string.Empty;

        [BsonElement("constelacion")]
        public string Constelacion { get; set; } = string.Empty;

        [BsonElement("rango")]
        public string Rango { get; set; } = string.Empty;

        [BsonElement("pais")]
        public string Pais { get; set; } = string.Empty;

        [BsonElement("edad")]
        public int Edad { get; set; }

        [BsonElement("habilidad_principal")]
        public string HabilidadPrincipal { get; set; } = string.Empty;

        [BsonElement("imagen_url")]
        public string ImagenURL { get; set; } = string.Empty;
    }
}
